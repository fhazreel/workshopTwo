<?php
$username = 'root';
$password = '';
$connection = new PDO( 'mysql:host=localhost;dbname=magiclean', $username, $password );

 
if(isset($_POST["query"]))
	{	
		
		$search = $_POST["query"];
		//$statement = $connection->prepare("SELECT * FROM vendor WHERE Name LIKE '%".$search."%' OR Verified LIKE '%".$search."%'");
		$statement = $connection->prepare("
		SELECT 
			vendor.VendorId, vendor.Name, vendor.Email, vendor.PhoneNo, vendor.ProfileImage,
			sum(case when request.JobId = 1 then 1 else 0 end) AS Cleaning, 
			sum(case when request.JobId = 2 then 1 else 0 end) AS Cooking, 
			sum(case when request.JobId = 3 then 1 else 0 end) AS Gardening,
			AVG(request.Rating) AS Rating,
			vendor.Verified
			FROM vendor
			INNER JOIN request ON vendor.VendorId=request.VendorId
			WHERE vendor.Name LIKE '%".$search."%' OR vendor.Email LIKE '%".$search."%' OR vendor.PhoneNo LIKE '%".$search."%' OR vendor.Verified LIKE '%".$search."%' 
			GROUP BY VendorId
			");
		$statement->execute();
		$result = $statement->fetchAll();
    
    $output = '';
   $output = '
   <table class="table table-bordered table-striped">  
    <tr>
	 <th width="13%">No</th>
     <th width="16%">Profile Image</th>
     <th width="25%">Name</th>
	 <th width="25%">Email</th>
	 <th width="25%">Phone Number</th>
	 <th width="25%">Cleaning</th>
	 <th width="25%">Cooking</th>
	 <th width="25%">Gardening</th>
	 <th width="25%">Rating</th>
	 <th width="30%">Status</th>
    </tr>
  ';
 $count=1;
 if($statement->rowCount() > 0)
   {
    foreach($result as $row)
    {
      $output .= '

      <tr>
	  <td>'.$count.'</td>  
      <td>	<img src="data:image/jpeg;base64,'.base64_encode($row['ProfileImage'] ).'" height="60" width="75" class="img-thumbnail" /></td>
      <td>'.$row["Name"].'</td>  
      <td>'.$row["Email"].'</td>  
      <td>'.$row["PhoneNo"].'</td>
	  <td>'.$row["Cleaning"].'</td>
	  <td>'.$row["Cooking"].'</td>
	  <td>'.$row["Gardening"].'</td>
	  <td>'.$row["Rating"].'</td> 
      <td>'.$row["Verified"].'</td>   

      </tr>
     ';
	 $count++;
    }
   }
   else
   {
		echo ' <div class="alert alert-danger alert-dismissible fade show">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <strong>Alert!</strong> Data not found.
  </div>';
   }
 
   $output .= ' </table>';
   echo $output;
	 
	} 

if(isset($_POST["action"]))
{
	
  if($_POST["action"] == "fetch")
 {
   //$statement = $connection->prepare("SELECT VendorId,  Name, Email, PhoneNo, ProfileImage, Verified FROM vendor ORDER BY VendorId DESC");
   $statement = $connection->prepare("
		SELECT 
			vendor.VendorId, vendor.Name, vendor.Email, vendor.PhoneNo, vendor.ProfileImage,
			sum(case when request.JobId = 1 then 1 else 0 end) AS Cleaning, 
			sum(case when request.JobId = 2 then 1 else 0 end) AS Cooking, 
			sum(case when request.JobId = 3 then 1 else 0 end) AS Gardening,
			AVG(request.Rating) AS Rating,
			vendor.Verified
			FROM vendor
			INNER JOIN request ON vendor.VendorId=request.VendorId
			GROUP BY VendorId");
   $statement->execute();
   $result = $statement->fetchAll();
   $output = '';
   $output = '
   <table class="table table-bordered table-striped">  
    <tr>
	 <th width="13%">No</th>
     <th width="16%">Profile Image</th>
     <th width="25%">Name</th>
	 <th width="25%">Email</th>
	 <th width="25%">Phone Number</th>
	 <th width="25%">Cleaning</th>
	 <th width="25%">Cooking</th>
	 <th width="25%">Gardening</th>
	 <th width="25%">Rating</th>
	 <th width="30%">Status</th>
    </tr>
  ';
  $count=1;
 if($statement->rowCount() > 0)
   {
    foreach($result as $row)
    {
      $output .= '

      <tr>
	  <td>'.$count.'</td> 
      <td>	<img src="data:image/jpeg;base64,'.base64_encode($row['ProfileImage'] ).'" height="60" width="75" class="img-thumbnail" /></td>
      <td>'.$row["Name"].'</td>  
      <td>'.$row["Email"].'</td>  
      <td>'.$row["PhoneNo"].'</td>  
	  <td>'.$row["Cleaning"].'</td>
	  <td>'.$row["Cooking"].'</td>
	  <td>'.$row["Gardening"].'</td> 	  
	  <td>'.$row["Rating"].'</td> 
      <td>'.$row["Verified"].'</td> 
      </tr>
     ';
	 $count++;
    }
   }
   else
   {
		echo 'Data Not Found';
   }
 
   $output .= ' </table>';
   echo $output;
}

}
?>



