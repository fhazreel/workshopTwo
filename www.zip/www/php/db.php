<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","root","","magiclean") or die ("could not connect database");
?>