<?php
include "db.php";


//check redundant data
if(isset($_POST['username']))
{
	$username=$_POST['username'];
	$password=$_POST['password'];

	//$q = mysqli_query($con,"SELECT * FROM `admin` WHERE Username='$username' AND Password='$password'");
	$sql = "SELECT * FROM `admin` WHERE Username='$username' AND Password='$password'";
      $result = mysqli_query($con,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
	    $count = mysqli_num_rows($result);
	if($count == 1){
		echo "success"; 
	}
		
	else {
		echo "error";
	}
		
	

}

?>