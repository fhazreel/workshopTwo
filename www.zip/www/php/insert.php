<?php
include "db.php";


//check redundant data
if(isset($_POST['insert']))
{
	$username=$_POST['username'];
	$password=$_POST['password'];

	$q=mysqli_query($con,"INSERT INTO `admin` (`Username`,`Password`) VALUES ('$username','$password')");
	if($q)

		echo "success";
	else
		echo "error";


}

?>