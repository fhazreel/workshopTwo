<?php
$username = 'root';
$password = '';
$connection = new PDO( 'mysql:host=localhost;dbname=magiclean', $username, $password );

 
 if(isset($_POST["query"]))
	{	
		
		$search = $_POST["query"];
		$statement = $connection->prepare("SELECT * FROM vendor WHERE Name LIKE '%".$search."%' OR PhoneNo LIKE '%".$search."%' OR Email LIKE '%".$search."%' OR Verified LIKE '%".$search."%'");
		$statement->execute();
		$result = $statement->fetchAll();
    
    $output = '';
   $output = '
   <table class="table table-bordered table-striped">  
    <tr>
	 <th width="13%">No</th>
     <th width="16%">Profile Image</th>
     <th width="25%">Name</th>
	 <th width="25%">Email</th>
	 <th width="25%">Phone Number</th>
	 <th width="30%">Status</th>
     <th width="50%">Action</th>
    </tr>
  ';
 $count=1;
 if($statement->rowCount() > 0)
   {
    foreach($result as $row)
    {
      $output .= '

      <tr>
	  <td>'.$count.'</td>  
      <td>	<img src="data:image/jpeg;base64,'.base64_encode($row['ProfileImage'] ).'" height="60" width="75" class="img-thumbnail" /></td>
      <td>'.$row["Name"].'</td>  
      <td>'.$row["Email"].'</td>  
      <td>'.$row["PhoneNo"].'</td>   
      <td>'.$row["Verified"].'</td> 
          <td> <button type="submit" name="delete" value="delete" class="btn btn-red btn-xs delete" id="'.$row["VendorId"].'">&#9747;</button>
               <br>
               <button type="submit" data-toggle="modal"  class="btn btn-yellow btn-xs  selectvendor" id="'.$row["VendorId"].'">&#9998;</button>
             </td>  
              
      </tr>
     ';
	 $count++;
    }
   }
   else
   {
		echo ' <div class="alert alert-danger alert-dismissible fade show">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <strong>Alert!</strong> Data not found.
  </div>';
   }
 
   $output .= ' </table>';
   echo $output;
	 
	} 

if(isset($_POST["action"]))
{
	
  if($_POST["action"] == "fetch")
 {
   $statement = $connection->prepare("SELECT VendorId,  Name, Email, PhoneNo, ProfileImage, Verified FROM vendor ORDER BY VendorId DESC");
   $statement->execute();
   $result = $statement->fetchAll();
   $output = '';
   $output = '
   <table class="table table-bordered table-striped">  
    <tr>
	 <th width="13%">No</th>
     <th width="16%">Profile Image</th>
     <th width="25%">Name</th>
	 <th width="25%">Email</th>
	 <th width="25%">Phone Number</th>
	 <th width="30%">Status</th>
     <th width="50%">Action</th>
    </tr>
  ';
  $count=1;
 if($statement->rowCount() > 0)
   {
    foreach($result as $row)
    {
      $output .= '

      <tr>
	  <td>'.$count.'</td> 
      <td>	<img src="data:image/jpeg;base64,'.base64_encode($row['ProfileImage'] ).'" height="60" width="75" class="img-thumbnail" /></td>
      <td>'.$row["Name"].'</td>  
      <td>'.$row["Email"].'</td>  
      <td>'.$row["PhoneNo"].'</td>   
      <td>'.$row["Verified"].'</td> 
          <td> <button type="submit" name="delete" value="delete" class="btn btn-red btn-xs delete" id="'.$row["VendorId"].'">&#9747;</button>
               <br>
               <button type="submit" data-toggle="modal"  class="btn btn-yellow btn-xs  selectvendor" id="'.$row["VendorId"].'">&#9998;</button>
             </td>  
              
      </tr>
     ';
	 $count++;
    }
   }
   else
   {
		echo 'Data Not Found';
   }
 
   $output .= ' </table>';
   echo $output;
}
	

 if($_POST["action"] == "SelectVendor")
 {
  $output = array();
  $statement = $connection->prepare("SELECT VendorId,  Name, Email, PhoneNo, Verified FROM vendor WHERE VendorId ='".$_POST["id"]."'");
  /**$statement = $connection->prepare(" 
  SELECT 
	vendor.VendorId, vendor.Name, vendor.Email, vendor.PhoneNo,
	sum(case when request.JobId = 1 then 1 else 0 end) AS Cleaning, 
	sum(case when request.JobId = 2 then 1 else 0 end) AS Cooking, 
	sum(case when request.JobId = 3 then 1 else 0 end) AS Gardening,
	vendor.Verified
	FROM vendor
	INNER JOIN request ON vendor.VendorId=request.VendorId
	WHERE vendor.VendorId='".$_POST["id"]."'"); **/
  
  $statement->execute();
  $result = $statement->fetchAll();
  foreach($result as $row)
  {
   $output["name"] = $row["Name"];
   $output["email"] = $row["Email"];
   $output["phoneno"] = $row["PhoneNo"];
   $output["verified"] = $row["Verified"];
  }
  echo json_encode($output);
 }

//update data
 if($_POST["action"] == "Update")
 {
  $statement = $connection->prepare(
   "UPDATE vendor 
   SET Verified = :verified
   WHERE VendorId = :id
   "
  );
  $result = $statement->execute(
   array(
    ':verified' => $_POST["verified"],
    ':id'   => $_POST["id"]
   )
  );
  if(!empty($result))
  {
   echo 'Data have been Updated';
  }
 } 
 
 //delete data
  if($_POST["action"] == "delete")
 {
  $statement = $connection->prepare(
   "DELETE FROM vendor WHERE VendorId = :id
   "
  );
  $result = $statement->execute(
   array(
    ':id'   => $_POST["id"]
   )
  );
  if(!empty($result))
  {
   echo 'Data have been deleted';
  }
 } 
}
?>



