MagiClean Services Admin System

Username: Admin
Password: 1234